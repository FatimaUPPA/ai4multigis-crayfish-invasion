# -*- coding: utf-8 -*-
"""
AI4MultiGIS Invasion Risk Plugin
=================================
QGIS 3.28+ plugin that loads the romania_river_risk.geojson output
from the AI4MultiGIS pipeline and applies a graduated colour style
by invasion risk level.

Installation:
    1. Copy the entire ai4multigis_plugin/ folder to:
       ~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/
    2. Open QGIS -> Plugins -> Manage and Install Plugins
    3. Enable "AI4MultiGIS Invasion Risk"
    4. The plugin appears in the Plugins menu and toolbar

Usage:
    1. Click the AI4MultiGIS toolbar button (or Plugins > AI4MultiGIS)
    2. Browse to your romania_river_risk.geojson file
    3. Click "Load & Style Layer"
    4. Optionally filter by risk level and export filtered results
"""

import os

from qgis.core import (
    QgsApplication,
    QgsFeatureRequest,
    QgsField,
    QgsProject,
    QgsVectorLayer,
    QgsVectorFileWriter,
    QgsCoordinateTransformContext,
    QgsCategorizedSymbolRenderer,
    QgsRendererCategory,
    QgsSymbol,
    QgsLineSymbol,
    QgsMessageLog,
    Qgis,
)
from qgis.PyQt.QtCore import QSettings, QVariant, Qt
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtWidgets import (
    QAction,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

# ── Risk level colour scheme (matches the Python script output) ─────────────
RISK_LEVELS = {
    "Very Low":  {"color": "#2d6a4f", "width": 0.4},
    "Low":       {"color": "#74c69d", "width": 0.6},
    "Moderate":  {"color": "#ffd166", "width": 0.9},
    "High":      {"color": "#f4845f", "width": 1.4},
    "Very High": {"color": "#c1121f", "width": 2.0},
}
RISK_ORDER = ["Very Low", "Low", "Moderate", "High", "Very High"]


# =============================================================================
# PLUGIN CLASS
# =============================================================================

class AI4MultiGISPlugin:
    """Main plugin class — registered by QGIS via classFactory."""

    def __init__(self, iface):
        self.iface   = iface
        self.action  = None
        self.dialog  = None

    def initGui(self):
        """Called by QGIS when the plugin is loaded. Creates menu + toolbar entry."""
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon      = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "AI4MultiGIS — Invasion Risk", self.iface.mainWindow())
        self.action.setToolTip("Load and visualise crayfish invasion risk on Romania's river network")
        self.action.triggered.connect(self.run)

        # Add to Plugins menu and toolbar
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("AI4MultiGIS", self.action)

    def unload(self):
        """Called by QGIS when the plugin is disabled/removed."""
        self.iface.removePluginMenu("AI4MultiGIS", self.action)
        self.iface.removeToolBarIcon(self.action)

    def run(self):
        """Open the plugin dialog."""
        self.dialog = AI4MultiGISDialog(self.iface)
        self.dialog.show()


# =============================================================================
# DIALOG (the plugin's UI window)
# =============================================================================

class AI4MultiGISDialog(QDialog):
    """Main plugin dialog window."""

    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface      = iface
        self.layer      = None
        self.geojson_path = None

        self.setWindowTitle("AI4MultiGIS — Faxonius limosus Invasion Risk")
        self.setMinimumWidth(520)
        self.setMinimumHeight(480)
        self._build_ui()

    # ── Build the UI layout ──────────────────────────────────────────────────

    def _build_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(10)
        main_layout.setContentsMargins(14, 14, 14, 14)

        # Header
        header = QLabel(
            "<b>AI4MultiGIS — Invasion Risk Visualiser</b><br>"
            "<span style='color:#555; font-size:11px;'>"
            "Faxonius limosus · Romania river network · 2025</span>"
        )
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet(
            "background:#f0f4ff; border:1px solid #c8d0e8; "
            "border-radius:6px; padding:8px;"
        )
        main_layout.addWidget(header)

        # ── File selection group ─────────────────────────────────────────────
        file_group = QGroupBox("Step 1 — Select risk GeoJSON file")
        file_layout = QHBoxLayout()

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Browse to romania_river_risk.geojson ...")
        self.path_edit.setReadOnly(True)

        browse_btn = QPushButton("Browse...")
        browse_btn.setFixedWidth(90)
        browse_btn.clicked.connect(self._browse_file)

        file_layout.addWidget(self.path_edit)
        file_layout.addWidget(browse_btn)
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)

        # ── Load button ──────────────────────────────────────────────────────
        load_group = QGroupBox("Step 2 — Load and style layer")
        load_layout = QVBoxLayout()

        self.load_btn = QPushButton("Load and Style Layer")
        self.load_btn.setFixedHeight(36)
        self.load_btn.setEnabled(False)
        self.load_btn.setStyleSheet(
            "QPushButton { background:#3a7bd5; color:white; border-radius:5px; "
            "font-weight:bold; font-size:13px; }"
            "QPushButton:hover { background:#2d64b8; }"
            "QPushButton:disabled { background:#aaa; }"
        )
        self.load_btn.clicked.connect(self._load_and_style)
        load_layout.addWidget(self.load_btn)
        load_group.setLayout(load_layout)
        main_layout.addWidget(load_group)

        # ── Risk level filter group ──────────────────────────────────────────
        filter_group = QGroupBox("Step 3 — Filter by risk level (optional)")
        filter_layout = QVBoxLayout()

        filter_label = QLabel("Show only selected risk levels on the map:")
        filter_label.setStyleSheet("color:#444; font-size:11px;")
        filter_layout.addWidget(filter_label)

        checkbox_row = QHBoxLayout()
        self.checkboxes = {}
        for level in RISK_ORDER:
            cb = QCheckBox(level)
            cb.setChecked(True)
            color = RISK_LEVELS[level]["color"]
            cb.setStyleSheet(
                f"QCheckBox::indicator:checked {{ background:{color}; "
                f"border:1px solid #555; border-radius:2px; }}"
                f"QCheckBox {{ font-size:11px; }}"
            )
            self.checkboxes[level] = cb
            checkbox_row.addWidget(cb)

        filter_layout.addLayout(checkbox_row)

        filter_btn_row = QHBoxLayout()
        apply_filter_btn = QPushButton("Apply Filter")
        apply_filter_btn.clicked.connect(self._apply_filter)
        apply_filter_btn.setStyleSheet(
            "QPushButton { background:#555; color:white; border-radius:4px; padding:4px 10px; }"
            "QPushButton:hover { background:#333; }"
        )
        reset_filter_btn = QPushButton("Show All")
        reset_filter_btn.clicked.connect(self._reset_filter)
        reset_filter_btn.setStyleSheet(
            "QPushButton { background:#888; color:white; border-radius:4px; padding:4px 10px; }"
            "QPushButton:hover { background:#666; }"
        )
        filter_btn_row.addWidget(apply_filter_btn)
        filter_btn_row.addWidget(reset_filter_btn)
        filter_btn_row.addStretch()
        filter_layout.addLayout(filter_btn_row)
        filter_group.setLayout(filter_layout)
        main_layout.addWidget(filter_group)

        # ── Export group ─────────────────────────────────────────────────────
        export_group = QGroupBox("Step 4 — Export filtered results (optional)")
        export_layout = QHBoxLayout()

        export_btn = QPushButton("Export Filtered Layer as GeoJSON...")
        export_btn.clicked.connect(self._export_filtered)
        export_btn.setStyleSheet(
            "QPushButton { background:#2d6a4f; color:white; border-radius:4px; padding:5px 10px; }"
            "QPushButton:hover { background:#1e4d38; }"
        )
        export_layout.addWidget(export_btn)
        export_group.setLayout(export_layout)
        main_layout.addWidget(export_group)

        # ── Log output ───────────────────────────────────────────────────────
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(100)
        self.log.setStyleSheet(
            "background:#1e1e1e; color:#d4d4d4; font-family:monospace; "
            "font-size:11px; border-radius:4px;"
        )
        main_layout.addWidget(self.log)

        # ── Close button ─────────────────────────────────────────────────────
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.close)
        close_btn.setFixedWidth(90)
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_row.addWidget(close_btn)
        main_layout.addLayout(btn_row)

        self.setLayout(main_layout)
        self._log("Plugin ready. Browse to your romania_river_risk.geojson file.")

    # ── UI helper methods ────────────────────────────────────────────────────

    def _log(self, message, level="info"):
        colors = {"info": "#d4d4d4", "ok": "#6fcf97", "warn": "#f2994a", "error": "#eb5757"}
        color  = colors.get(level, "#d4d4d4")
        self.log.append(f"<span style='color:{color};'>{message}</span>")
        QgsMessageLog.logMessage(message, "AI4MultiGIS", Qgis.Info)

    def _browse_file(self):
        """Open file browser to select the GeoJSON risk file."""
        last_dir = QSettings().value("ai4multigis/last_dir", os.path.expanduser("~"))
        path, _ = QFileDialog.getOpenFileName(
            self, "Select risk GeoJSON file", last_dir,
            "GeoJSON files (*.geojson *.json);;All files (*.*)"
        )
        if path:
            self.geojson_path = path
            self.path_edit.setText(path)
            self.load_btn.setEnabled(True)
            QSettings().setValue("ai4multigis/last_dir", os.path.dirname(path))
            self._log(f"Selected: {os.path.basename(path)}")

    # ── Core methods ─────────────────────────────────────────────────────────

    def _load_and_style(self):
        """Load the GeoJSON file as a QGIS vector layer and apply risk styling."""
        if not self.geojson_path or not os.path.exists(self.geojson_path):
            QMessageBox.warning(self, "File not found",
                                "Please select a valid GeoJSON file first.")
            return

        self._log("Loading GeoJSON layer...")

        # Load as vector layer
        layer_name = "Invasion Risk — Romania Rivers"
        self.layer = QgsVectorLayer(self.geojson_path, layer_name, "ogr")

        if not self.layer.isValid():
            self._log("ERROR: Could not load layer. Check the file path.", "error")
            QMessageBox.critical(self, "Load error",
                                 "Could not load the GeoJSON file.\n"
                                 "Make sure it was generated by the romania_risk_projection.py script.")
            return

        # Check required fields
        field_names = [f.name() for f in self.layer.fields()]
        if "risk_level" not in field_names:
            self._log("ERROR: 'risk_level' field not found in GeoJSON.", "error")
            QMessageBox.critical(self, "Field missing",
                                 "The 'risk_level' field was not found.\n"
                                 "Regenerate the GeoJSON using romania_risk_projection.py.")
            return

        # Apply categorised style by risk_level
        self._apply_risk_style()

        # Add to QGIS project
        QgsProject.instance().addMapLayer(self.layer)

        # Zoom to layer extent
        self.iface.mapCanvas().setExtent(self.layer.extent())
        self.iface.mapCanvas().refresh()

        # Count features per risk level
        counts = self._count_by_risk_level()
        total  = self.layer.featureCount()
        self._log(f"Loaded {total:,} river segments.", "ok")
        for level in RISK_ORDER:
            n   = counts.get(level, 0)
            pct = n / total * 100 if total > 0 else 0
            self._log(f"  {level:10s}: {n:5,}  ({pct:.1f}%)")

        self._log("Layer styled and added to map.", "ok")

    def _apply_risk_style(self):
        """Apply a categorised renderer coloured by risk_level field."""
        categories = []
        for level in RISK_ORDER:
            cfg   = RISK_LEVELS[level]
            symbol = QgsLineSymbol.createSimple({
                "color":      cfg["color"],
                "line_width": str(cfg["width"]),
                "capstyle":   "round",
                "joinstyle":  "round",
            })
            category = QgsRendererCategory(level, symbol, level)
            categories.append(category)

        renderer = QgsCategorizedSymbolRenderer("risk_level", categories)
        self.layer.setRenderer(renderer)
        self.layer.triggerRepaint()

    def _apply_filter(self):
        """Show only the risk levels whose checkboxes are ticked."""
        if not self.layer or not self.layer.isValid():
            self._log("No layer loaded yet.", "warn")
            return

        selected = [lvl for lvl, cb in self.checkboxes.items() if cb.isChecked()]
        if not selected:
            self._log("No risk levels selected — showing all.", "warn")
            self.layer.setSubsetString("")
            return

        # Build SQL filter expression
        quoted = ", ".join(f"'{lvl}'" for lvl in selected)
        expr   = f'"risk_level" IN ({quoted})'
        self.layer.setSubsetString(expr)
        self.iface.mapCanvas().refresh()
        self._log(f"Filter applied: {', '.join(selected)}", "ok")

    def _reset_filter(self):
        """Remove all filters and show all risk levels."""
        if not self.layer or not self.layer.isValid():
            return
        for cb in self.checkboxes.values():
            cb.setChecked(True)
        self.layer.setSubsetString("")
        self.iface.mapCanvas().refresh()
        self._log("Filter cleared — showing all risk levels.", "ok")

    def _export_filtered(self):
        """Export currently visible (filtered) features to a new GeoJSON file."""
        if not self.layer or not self.layer.isValid():
            self._log("No layer loaded yet.", "warn")
            QMessageBox.warning(self, "No layer", "Please load a layer first.")
            return

        last_dir = QSettings().value("ai4multigis/last_dir", os.path.expanduser("~"))
        out_path, _ = QFileDialog.getSaveFileName(
            self, "Save filtered layer", last_dir,
            "GeoJSON (*.geojson);;All files (*.*)"
        )
        if not out_path:
            return

        options                    = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName         = "GeoJSON"
        options.fileEncoding       = "UTF-8"
        options.onlySelectedFeatures = False

        error, msg, _, _ = QgsVectorFileWriter.writeAsVectorFormatV3(
            self.layer,
            out_path,
            QgsCoordinateTransformContext(),
            options,
        )

        if error == QgsVectorFileWriter.NoError:
            self._log(f"Exported to: {os.path.basename(out_path)}", "ok")
            QMessageBox.information(self, "Export successful",
                                    f"Filtered layer saved to:\n{out_path}")
        else:
            self._log(f"Export failed: {msg}", "error")
            QMessageBox.critical(self, "Export failed", f"Could not save file:\n{msg}")

    # ── Utilities ────────────────────────────────────────────────────────────

    def _count_by_risk_level(self):
        """Count features per risk_level value."""
        counts = {lvl: 0 for lvl in RISK_ORDER}
        for feat in self.layer.getFeatures():
            lvl = feat["risk_level"]
            if lvl in counts:
                counts[lvl] += 1
        return counts
