# -*- coding: utf-8 -*-
"""
AI4MultiGIS Invasion Risk Plugin
Required by QGIS plugin architecture.
"""


def classFactory(iface):
    from .ai4multigis_plugin import AI4MultiGISPlugin
    return AI4MultiGISPlugin(iface)
